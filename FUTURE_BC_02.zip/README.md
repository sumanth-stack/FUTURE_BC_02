# FUTURE_BC_02 - Future Interns Blockchain Task 02

## 🚀 Task: Build a Free Crypto Token on Polygon/BNB Testnet

### Token Details
- **Name**: FutureInternsToken
- **Symbol**: FIT
- **Initial Supply**: 1,000,000 (1M)

### 📜 Contract File
Located in `contracts/FutureInternsToken.sol`

### ⚡ Deployment Steps (Polygon Mumbai or BNB Testnet)
1. Open [Remix IDE](https://remix.ethereum.org/)
2. Create a new file `FutureInternsToken.sol` and paste the contract code.
3. Compile using Solidity ^0.8.0.
4. Deploy using **Injected Web3** with MetaMask connected to Polygon Mumbai or BNB Testnet.
5. Get test tokens from faucet if needed.
6. Copy the contract address and verify it on [PolygonScan](https://mumbai.polygonscan.com) or [BscScan Testnet](https://testnet.bscscan.com).

### ✅ Deliverables
1. Smart contract uploaded here on GitHub.
2. Testnet token address.
3. MetaMask screenshot showing FIT balance.
4. Explorer link of deployed contract.

---
This repository is created as part of **Future Interns Blockchain & Crypto Internship - Task 02**.
